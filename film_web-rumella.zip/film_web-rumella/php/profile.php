<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: ../html/login.html');
    exit();
}

$user_id = $_SESSION['user_id'];

$query = "SELECT name, surname, birth_date, gender, email, authority_id, profile_photo FROM clients WHERE id = ?";
$stmt = $conn->prepare($query);
if (!$stmt) {
    die('Sorgu hatası: ' . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    die('Kullanıcı bulunamadı!');
}
$user = $result->fetch_assoc();

$authority = match ($user['authority_id']) {
    1 => 'Admin',
    2 => 'Personel',
    3 => 'Kullanıcı',
    default => 'Bilinmiyor'
};

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Profilim</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- FontAwesome CDN -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>

body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(120deg, #dfe9f3, #ffffff);
    color: #333;
}

.profile-wrapper {
    max-width: 1100px;
    margin: 40px auto;
    padding: 40px;
    background: rgba(255, 255, 255, 0.15);
    border-radius: 30px;
    backdrop-filter: blur(15px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    border: 1px solid rgba(255, 255, 255, 0.3);
}

.profile-container {
    display: flex;
    gap: 60px;
    flex-wrap: wrap;
    justify-content: center;
}

.left-column {
    flex: 0 0 260px;
    text-align: center;
}

.profile-photo {
    width: 180px;
    height: 180px;
    border-radius: 50%;
    object-fit: cover;
    border: 4px solid #4dabf7;
    box-shadow: 0 0 30px rgba(0, 123, 255, 0.3);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.profile-photo:hover {
    transform: scale(1.06);
    box-shadow: 0 0 50px rgba(0, 123, 255, 0.5);
}

.name-card {
    margin-top: 20px;
    background-color: #e9f2ff;
    color: #007bff;
    font-size: 22px;
    font-weight: 700;
    padding: 14px 24px;
    border-radius: 14px;
    border-left: 6px solid #007bff;
    display: inline-block;
    backdrop-filter: blur(8px);
}

.right-column {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.info-card {
    background-color: #f8f9fa;
    border-left: 6px solid #007bff;
    padding: 20px 28px;
    border-radius: 16px;
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.06);
    backdrop-filter: blur(8px);
    transition: all 0.4s ease;
    transition: box-shadow 0.3s;
}

.info-card:hover {
    transform: scale(1.02);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}

.info-label {
    font-size: 14px;
    font-weight: 600;
    color: #444;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    margin-bottom: 4px;
}

.info-label i {
    margin-right: 8px;
    color: #007bff;
    transition: transform 0.3s ease;
}

.info-card:hover .info-label i {
    transform: scale(1.2);
}


.info-value {
    font-size: 17px;
    color: #212529;
}

@media (max-width: 768px) {
    .profile-container {
        flex-direction: column;
        align-items: center;
    }
}

    </style>
</head>
<body>

<?php
$navbarTitle = "Profilim";
$navbarItems = ['home', 'dashboard', 'add_comment', 'edit_profile', 'logout'];
include 'navbar.php';
?>

<div class="profile-wrapper">
    <div class="profile-container">
        <div class="left-column">
            <img class="profile-photo"
                 src="<?php echo !empty($user['profile_photo']) && file_exists('../uploads/' . $user['profile_photo']) ? '../uploads/' . htmlspecialchars($user['profile_photo']) : '../assets/default_profile.png'; ?>"
                 alt="Profil Fotoğrafı">

            <div class="name-card">
                <?php echo htmlspecialchars($user['name'] . ' ' . $user['surname']); ?>
            </div>
        </div>

        <div class="right-column">
            <div class="info-card">
    <div class="info-label"><i class="fas fa-envelope"></i> E-posta</div>
    <div class="info-value"><?php echo htmlspecialchars($user['email']); ?></div>
</div>

<div class="info-card">
    <div class="info-label"><i class="fas fa-calendar-alt"></i> Doğum Tarihi</div>
    <div class="info-value"><?php echo htmlspecialchars($user['birth_date']); ?></div>
</div>

<div class="info-card">
    <div class="info-label"><i class="fas fa-venus-mars"></i> Cinsiyet</div>
    <div class="info-value"><?php echo htmlspecialchars($user['gender']); ?></div>
</div>

<div class="info-card">
    <div class="info-label"><i class="fas fa-user-shield"></i> Yetki</div>
    <div class="info-value"><?php echo $authority; ?></div>
</div>

        </div>
    </div>
</div>

</body>
</html>
